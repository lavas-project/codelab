import Vue from 'vue';
import Router from 'vue-router';

    
import _151365261116433bea917df934b120779c7b632c0284b from '@/pages/appshell/Main.vue';
    

    
import _15136526111646a992d5529f459a44fee58c733255e86 from '@/pages/Index.vue';
    

    
import _1513652611164d56b699830e77ba53855679cb1d252da from '@/pages/Login.vue';
    

    
import _1513652611164cb5e100e5a9a3e7f6d1fd97512215282 from '@/pages/Error.vue';
    


let routes = [
    {
                path: '/appshell/Main',
                name: 'appshellMain',
                component: _151365261116433bea917df934b120779c7b632c0284b,
                meta: {},
                
                
            },{
                path: '/',
                name: 'index',
                component: _15136526111646a992d5529f459a44fee58c733255e86,
                meta: {},
                
                
            },{
                path: '/login',
                name: 'login',
                component: _1513652611164d56b699830e77ba53855679cb1d252da,
                meta: {},
                
                
            },{
                    path: '/error',
                    name: 'error',
                    component: _1513652611164cb5e100e5a9a3e7f6d1fd97512215282,
                    meta: {},
                    alias: '*'
                },
];

Vue.use(Router);




const scrollBehavior = (to, from, savedPosition) => {
    if (savedPosition) {
        return savedPosition;
    } else {
        const position = {};
        // scroll to anchor by returning the selector
        if (to.hash) {
            position.selector = to.hash;
        }
        // check if any matched route config has meta that requires scrolling to top
        if (to.matched.some(m => m.meta.scrollToTop)) {
            // cords will be used if no selector is provided,
            // or if the selector didn't match any element.
            position.x = 0
            position.y = 0
        }
        // if the returned position is falsy or an empty object,
        // will retain current scroll position.
        return position;
    }
};


export function createRouter() {
    let router = new Router({
        mode: 'history',
        base: '/',
        scrollBehavior,
        routes
    });


    router.beforeEach((to, from, next) => {
        if (router.app.$store) {
            if (router.app.$store.state.pageTransition.enable) {
                
                let effect = 'fade';
                
                router.app.$store.commit('pageTransition/setType', 'fade');
                router.app.$store.commit('pageTransition/setEffect', effect);
            }
        }
        next();
    });


    return router;
}
